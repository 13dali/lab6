

import java.io.File;

//Its a thread class used to Crawler through the data It will always make 5 child threads for searching
//Fields PATH,ThreadCount
public class CrawlerThread extends Thread {


	private String PATH;
	public static int threadCount;
	
	public CrawlerThread(String path)
	{
		this.PATH = path;
	}
	
	//Main Run Method
	public void run()
	{
		threadCount++;
		//System.out.println("Starting New");
		craweler(new File(PATH));
		threadCount--;
	}
	
	public void craweler(File root)
	{
		File[] file = root.listFiles();
		for(int i = 0; i < file.length ; i++)
		    if(file[i].isDirectory())
		    {
		    	if(threadCount < 5)
		    	{
		    		CrawlerThread thread = new CrawlerThread(file[i].getAbsolutePath());
		    		thread.run();
		    	}
		    	else
		    	{
		    		//System.out.println(file[i].getAbsolutePath());
		    		craweler(file[i]);
		    	}
		    }
		    else
		    {
		    	if(file[i].getName().contains(".txt")){
		    		JCrawler.filesTobeIndexed.add(file[i]);
		    	}
		    }
	}
}
