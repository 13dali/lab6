

import java.util.Scanner;

//User Assistance and Interaction class
public class Searching implements Runnable {

	private Scanner sc;
	
	@Override
	public void run() {

		display("Enter a String to search");
		
		Boolean keepGoing = true;
		sc = new Scanner(System.in);
		
		while(keepGoing)
		{
			display("Enter Text to search Press Q to exit");
			String text = sc.nextLine();
			if(text.equalsIgnoreCase("q"))
				keepGoing = false;
			else
			{
				search(text);
				display("---------------------");
			}
		}
	}
	
	
	
	

	private void display(String display)
	{
		System.out.println(display);
	}
	

	public void search(String text) {
		Boolean found = false;
		MyMap map = JCrawler.map;
		for(int i = 0 ; i < map.getLength(); i++)
		{
			if(map.getKeyAt(i).equalsIgnoreCase(text)){
				display(text + " In file: " + map.getValueAt(i)); 
				found = true;
			}
			
		}
		
		if(!found)
			display("No Search Found");
	}
}
