

import static org.junit.Assert.*;

import java.io.File;

import org.junit.Test;

public class MyTests {

	@Test
	public void pathExists() 
	{
		File file = new File(JCrawler.PATH);
		if(!file.exists())
			fail("Change Path to valid directory");
	}
	
	@Test
	public void search() 
	{
		String wordToSearch = "#include";
		
		JCrawler crawler = new JCrawler();
		crawler.StartTest();
		if(JCrawler.map.getLength() < 1)
			fail("Nop File Found");
		
		if(crawler.search(wordToSearch) < 1)
			fail("Not Item Found");
		
	}
	
	

}
