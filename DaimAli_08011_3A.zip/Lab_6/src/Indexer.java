

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

//Indexer Class used to index what the Crawler has find out
public class Indexer implements Runnable {

	
	//Main Run Method
	public void run()
	{
		while(true)
		{
			if(JCrawler.filesTobeIndexed.size() == 0)
			{
				try {
					Thread.sleep(1500);
				} catch (InterruptedException e) {
					//e.printStackTrace();
				}
			}
			else
			{
				ArrayList<File> filesTobeIndexed = new ArrayList<File>();
				for(int i = 0; i < 
				JCrawler.filesTobeIndexed.size(); i++)
				{
					filesTobeIndexed.add(JCrawler.filesTobeIndexed.get(i));
				}
				JCrawler.filesTobeIndexed.clear();
				
				for(int i = 0; i < filesTobeIndexed.size(); i++)
				{
					index(filesTobeIndexed.get(i));
				}
				
			}
		}
	}
	
	private synchronized void index(File file) 
	{
		try
		{
			List<String> lines = Files.readAllLines(Paths.get(file.getAbsolutePath()),StandardCharsets.UTF_8);
			for(String line: lines)
			{
				String[] words = line.split(" ");
				for(String s: words)
				{
					JCrawler.map.put(s, file.getAbsolutePath());
				}
			}
		}
		catch(IOException e)
		{
			//System.out.println(file.getAbsolutePath());
			//e.printStackTrace();
		}
	}
}
