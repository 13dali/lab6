

import java.io.File;
import java.util.ArrayList;

public class JCrawler 
{
	public static final String PATH = "E:\\";
	static MyMap map;
	static ArrayList<File> filesTobeIndexed;
	

	
	public JCrawler()
	{
		 map = new MyMap();
		 filesTobeIndexed = new ArrayList<File>();
	}
	
	
	public static void main(String [] args)
	{
		JCrawler crawler = new JCrawler();
		crawler.start();
	}

	public void start() 
	{
		display("Searching");
		
		Thread thread = new CrawlerThread(PATH);
		thread.setDaemon(true);
		thread.start();

		Thread indexerThread = new Thread(new Indexer());
		indexerThread.setDaemon(true);
		indexerThread.start();
	
		Thread searching = new Thread(new Searching());
		searching.start();
		
		try {
			thread.join();
			searching.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
			
		display("Byyy");
	}
	
	
	public void StartTest()
	{
display("Searching");
		
		Thread thread = new CrawlerThread(PATH);	//Crawling Thread
		thread.setDaemon(true);						//Making It daemon
		thread.start();								//Starting it

		Thread indexerThread = new Thread(new Indexer());		//Indexing Thread
		indexerThread.setDaemon(true);							//Making it daemon
		indexerThread.start();									//Starting it

		try {
			thread.join();								//Joining it so all the searing should be completed till now
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	public int search(String text) {
		Boolean found = false;
		int results = 0;
		for(int i = 0 ; i < map.getLength(); i++)
		{
			if(map.getKeyAt(i).equalsIgnoreCase(text)){
				display(text + " In file: " + map.getValueAt(i)); 
				found = true;
				results++;
				}
		}
		
		if(!found)
			display("No Search Found");
		
		return results;
	}

	private void display(String display)
	{
		System.out.println(display);
	}
	
	
}
